/* Nome: Arthur Rocha Almeida
Matricula: 559861
*/
import IO.*;
public class Exerc�cio05
{ 
   public static void main (String [] args)
   {
     int A,B;
       A = IO.readint ("Entre com um valor inteiro: ");
       B = IO.readint ("Entre com outro valor inteiro: ");
       if (A%B == 0){
         IO.println ("A � divis�vel por B");
         }
       else {
         IO.println ("A n�o � divis�vel por B");
         }
   }
}             
