/* Nome: Arthur Rocha Almeida
Matricula: 559861
*/
// depend�ncias
import IO.*;
// classe pincipal
public class Exerc�cio01
{
// m�todo principal 
   public static void main (String [] args){
   // declara��o de vari�veis
      int x,y,z;
      y = 2;
   // ler dado do teclado 
      x = IO.readint ("Entre com um valor inteiro: ");
      z = x%y; 
   // condicionar
      if (z > 0){
         IO.println ("Seu n�mero � �mpar");
      }
      else{
         IO.println ("Seu n�mero � par");
      }
      IO.pause ("Aperte ENTER ara terminar");
   // fim m�todo principal      
   }
// fim classe Exercicio1    
}