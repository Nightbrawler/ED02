/* Nome: Arthur Rocha Almeida
Matricula: 559861
*/
import IO.*;
public class Exerc�cio07
{ 
   public static void main (String [] args)
   {
    int x,y,z;
      x = IO.readint ("Entre com um valor inteiro: ");
      y = IO.readint ("Entre com outro valor inteiro: ");
      z = IO.readint ("Entre com outro valor inteiro: ");
    if ((x < y + z) && (y < z + x) && (z < x + y)) {
        IO.println ("� um tri�ngulo ");
       if (( x == y) && ( x == z)){
          IO.println ("Equil�tero");
          }
       else if (( x == y ) || ( x == z ) || ( z == y )) {
          IO.println ("Is�celes");
          }
       else {
          IO.println ("Escaleno");
          }
       }   
    else {
       IO.println ("N�o � tri�ngulo");
       }
   }
}                    
           