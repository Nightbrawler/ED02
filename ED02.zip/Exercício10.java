/* Nome: Arthur Rocha Almeida
Matricula: 559861
*/
import IO.*;
public class Exerc�cio10
{ 
   public static void main (String [] args)
   {
    int n,i;
    double h = 0.0;
     n = IO.readint ("Entre com um valor inteiro: ");
      for (i = 1; i <= n; i++) 
      {
         h = h + 1.0/i;
      }
    IO.println ("H = " + h);
   }
}         