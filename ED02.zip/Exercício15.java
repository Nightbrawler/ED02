/* Nome: Arthur Rocha Almeida
Matricula: 559861
*/
import IO.*;
public class Exerc�cio15
{ 
   public static void main (String [] args)
   {
     int quantidade = 0;
     double nota = 0.0, soma = 0.0, media = 0.0;
     while (nota != -1)
     {
       nota = IO.readdouble ("Digite a nota (-1 para encerrar).");
       if (nota >= 0)
       { 
         soma = soma + nota;
         quantidade = quantidade + 1;
       }
     }
     if (quantidade > 0)
     {
       media = soma/quantidade;
       if (media % 2 == 0)
       { 
         IO.println ("A m�dia das notas � par.");
       }
       else 
       {
         IO.println ("A m�ia das notas � �mpar.");
       }
     }
     else 
     {
       IO.println ("N�o foram digitadas notas v�lidas.");
     }
   }
}               