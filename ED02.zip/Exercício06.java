/* Nome: Arthur Rocha Almeida
Matricula: 559861
*/
import IO.*;
public class Exerc�cio06
{ 
   public static void main (String [] args)
   {
     int x;
       x = IO.readint ("Entre com um valor inteiro: ");
       if ((x%3 == 0) && (x%7 == 0)){
         IO.println ("Seu numero � divis�vel por 3 e por 7 ao mesmo tempo");
         }
       else {
         IO.println ("Seu n�mero n�o � divis�vel por 3 e por 7 ao mesmo tempo");
         }
       IO.pause ("Aperte ENTER para terminar");
   }
}            