/* Nome: Arthur Rocha Almeida
Matricula: 559861
*/
import IO.*;
public class Exerc�cio08
{ 
   public static void main (String [] args)
   {
    int x;
    double pag,troco;
     IO.println (" --M�QUINA DE REFRIGERANTE-- ");
     IO.println (" 1 - Coca-cola  -  R$4,00 ");
     IO.println (" 2 - Fanta      -  R$3,80 ");
     IO.println (" 3 - Guaran�    -  R$3,50 ");
     IO.println (" 4 - Sprite     -  R$3,00 ");
     IO.println (" 5 - Picolino   -  R$2,50 ");
     x = IO.readint ("Escolha uma op��o: ");
    switch (x){
      case 1:
         pag = IO.readdouble ("Voc� escolheu 'Coca-cola'. Entre com o valor que deseja pagar: ");
         troco = pag - 4.00;
         IO.println ("Seu troco �: R$" + troco);
      break;
      case 2:
         pag = IO.readdouble ("Voc� escolheu 'Fanta'. Entre com o valor que deseja pagar: ");
         troco = pag - 3.80;
         IO.println ("Seu troco �: R$" + troco);
      break;
      case 3:
         pag = IO.readdouble ("Voc� escolheu 'Guaran�'. Entre com o valor que deseja pagar: ");
         troco = pag - 3.50;
         IO.println ("Seu troco �: R$" + troco);
      break;
      case 4:
         pag = IO.readdouble ("Voc� escolheu 'Sprite'. Entre com o valor que deseja pagar: ");
         troco = pag - 3.00;
         IO.println ("Seu troco � R$" + troco);
      break;
      case 5:
         pag = IO.readdouble ("Voc� escolheu 'Picolino'. Entre com o valor que deseja pagar: ");
         troco = pag - 2.50;
         IO.println ("Seu troco � R$" + troco);
      break;
      default:
      IO.println ("Obrigado, e volte sempre.");
      break;
    }            
   }  
}      
      
     
    