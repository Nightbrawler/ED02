/* Nome: Arthur Rocha Almeida
Matricula: 559861
*/
import IO.*;
public class Exerc�cio04
{ 
   public static void main (String [] args)
   {
     int x;
       x = IO.readint ("Entre com um valor rinteiro: ");
        if (x%3 == 0){
          IO.println ("� m�ltiplo de tr�s");
          }
        else {
          IO.println ("N�o � m�ltiplo de tr�s");
          }
   }
}             