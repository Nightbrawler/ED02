/* Nome: Arthur Rocha Almeida
Matricula: 559861
*/
import IO.*;
public class Exerc�cio03
{ 
   public static void main (String [] args)
   {
    int x,y,z;
     x = IO.readint ("Entre com um valor inteiro: ");
     y = IO.readint ("Entre com outro valor inteiro: ");
     z = ( x + y );
      if (z > 20){
         IO.println ("Resultado = " + (z + 8));
         }
      else {
         IO.println ("Resultado = " + (z - 5));
         }
   }
}            
