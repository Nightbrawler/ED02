/* Nome: Arthur Rocha Almeida
Matricula: 559861
*/
import IO.*;
public class Exerc�cio11
{ 
   public static void main (String [] args)
   {
     int n, x;
      double i, s = 0.0;
      n = IO.readint("Digite um numero inteiro: ");
      x = n;
      for(i = 1.0; i <= x; i++)
      {
         s = s + i/n;
         n = n-1;
      }
      IO.println("Resultado = "+s);
   }
}
