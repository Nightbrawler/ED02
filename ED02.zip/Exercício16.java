/* Nome: Arthur Rocha Almeida
Matricula: 559861
*/
import IO.*;
public class Exerc�cio16
{ 
   public static void main (String [] args)
   {
    int x,y = 0;
    x = IO.readint ("Entre com um valor inteiro: ");
    while (y != 1)
    {
     if (x % 2 == 0)
     {
       y = x/2;
       x = y;
     }
     else
     {
       y = 3 * x + 1;
       x = y;
     }
     IO.println (y);
    }
   }
} // fim class Exerc�cio16           