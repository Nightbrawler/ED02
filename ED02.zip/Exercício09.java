/* Nome: Arthur Rocha Almeida
Matricula: 559861
*/
import IO.*;
public class Exerc�cio09
{ 
   public static void main (String [] args)
   {
    int n, x, i, contador = 0;
      n = IO.readint("Digite a quantidade de numeros que deseja digitar: ");
      for(i = 0;i < n; i++)
      {
         x = IO.readint("Digite um numero inteiro: ");
         if (x % 2 ==0 && x >= 30)
         {
            contador = contador + 1;
         }
      }
      IO.println("\nQuantidade de numeros pares e maiores ou iguais a 30 = "+contador);
   }
}