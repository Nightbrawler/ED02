/* Nome: Arthur Rocha Almeida
Matricula: 559861
*/
import IO.*;
public class Exerc�cio14
{ 
   public static void main (String [] args)
   {
     int n, i, z, w;
     double x, y;
     n = IO.readint ("Digite a quantidade de valores: ");
     for (i = 0; i < n; i++)
     {
        x = IO.readdouble ("Entre com um valor real: ");
        y = IO.readdouble ("Entre com outro valor real: ");
         if (( x < -25 || x > 25 ) && ( y < -25 || y > 25 ))
         {
           if ( x != y )
           {  
              z = (int)x;
              w = (int)y;
              if (( z % 2 != 0 ) && ( w % 2 != 0 ))
              { 
                 if (x < y)
                 { 
                  IO.println (x);
                  IO.println (y);
                 }
              }
           }
         }
     }
   }
}                  