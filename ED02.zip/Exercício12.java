/* Nome: Arthur Rocha Almeida
Matricula: 559861
*/
import IO.*;
public class Exerc�cio12
{ 
   public static void main (String [] args)
   {
     int n, i, x;
      n = IO.readint("Digite a quantidade de valores: ");
      for(i = 0; i < n; i++)
      {
         x = IO.readint("Digite um valor inteiro: ");
         if(x > -15 && x < 35)
         {
            IO.println("Valor entre -15 e 35: " + x);
         }
      }
   }
}