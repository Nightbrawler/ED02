/* Nome: Arthur Rocha Almeida
Matricula: 559861
*/
import IO.*;
public class Exerc�cio02
{ 
   public static void main (String [] args)
   {
    int x;
      x = IO.readint ("Entre com um valor inteiro: ");
       if (x > 0){ 
         IO.println ("Positivo");
        }
       else if (x < 0){
         IO.println ("Negativo");
        }
       else {
         IO.println ("Zero");
        } 
   }
}        